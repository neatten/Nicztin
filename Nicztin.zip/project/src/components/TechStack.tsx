import React from 'react';
import { Heart } from 'lucide-react';

const tools = [
  { name: 'Vite', url: 'https://vitejs.dev/' },
  { name: 'React', url: 'https://react.dev/' },
  { name: 'Angular', url: 'https://angular.dev/' },
  { name: 'Vue', url: 'https://vuejs.org/' },
  { name: 'Solid', url: 'https://www.solidjs.com/' },
  { name: 'Svelte', url: 'https://svelte.dev/' },
  { name: 'Preact', url: 'https://preactjs.com/' },
  { name: 'Astro', url: 'https://astro.build/' },
  { name: 'Remix', url: 'https://remix.run/' },
  { name: 'Nuxt', url: 'https://nuxt.com/' },
  { name: 'Qwik', url: 'https://qwik.dev/' },
  { name: 'RedwoodJS', url: 'https://redwoodjs.com/' },
  { name: 'Nx', url: 'https://nx.dev/' },
  { name: 'Vercel', url: 'https://vercel.com/' },
  { name: 'Inkeep', url: 'https://inkeep.com/' },
  { name: 'StackBlitz', url: 'https://stackblitz.com/' },
];

const logos = [
  'Vite', 'React', 'Angular', 'Vue', 'Solid', 'Svelte',
  'Preact', 'Astro', 'Remix', 'Nuxt', 'Qwik', 'RedwoodJS'
];

export default function TechStack() {
  return (
    <section className="py-10 md:py-20 bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-2xl md:text-3xl font-bold text-center mb-6 md:mb-12 text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-600">
          Tech Stack & Tools We Recommend
        </h2>
        
        {/* Sliding Logos */}
        <div className="overflow-hidden mb-12">
          <div className="flex space-x-8 animate-scroll">
            {[...logos, ...logos].map((logo, index) => (
              <span
                key={index}
                className="text-2xl font-bold whitespace-nowrap text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-600"
              >
                {logo}
              </span>
            ))}
          </div>
        </div>

        <div className="tech-grid grid grid-cols-2 md:grid-cols-4 gap-4">
          {tools.map((tool) => (
            <a
              key={tool.name}
              href={tool.url}
              target="_blank"
              rel="noopener noreferrer"
              className="p-4 rounded-lg bg-white/5 hover:bg-white/10 transition-all duration-300 text-center group"
            >
              <span className="text-gray-300 group-hover:text-white transition-colors duration-300">
                {tool.name}
              </span>
            </a>
          ))}
        </div>

        {/* Sponsor Section */}
        <div className="mt-12 text-center">
          <a
            href="https://www.paypal.com/myaccount/money/cards/CC-4URFUH8V4QCHE"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-gradient-to-r from-purple-400 to-pink-600 hover:from-purple-500 hover:to-pink-700 transition-all duration-300 group"
          >
            <Heart className="w-5 h-5 group-hover:animate-pulse" />
            <span className="font-semibold">Sponsor Nicztin</span>
          </a>
        </div>
      </div>
    </section>
  );
}