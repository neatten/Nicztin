import React from 'react';
import {
  Boxes,
  Flame,
  Atom,
  Mountain,
  Sparkles,
  Rocket,
  Zap,
  Star,
  Sun,
  Moon,
  Laptop,
  Code,
  Music,
  Headphones,
  Radio,
  Mic
} from 'lucide-react';

const tools = [
  { name: 'Music Production', icon: Music },
  { name: 'Sound Engineering', icon: Headphones },
  { name: 'Radio', icon: Radio },
  { name: 'Recording', icon: Mic },
  { name: 'Vite', icon: Flame },
  { name: 'React', icon: Atom },
  { name: 'Angular', icon: Mountain },
  { name: 'Vue', icon: Sparkles },
  { name: 'Solid', icon: Rocket },
  { name: 'Svelte', icon: Zap },
  { name: 'Preact', icon: Star },
  { name: 'Astro', icon: Sun },
];

export default function ScrollingLogos() {
  return (
    <div className="relative py-20 space-y-12 bg-black overflow-hidden">
      {/* ViteConf-style diagonal stripes */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute inset-0 bg-[linear-gradient(45deg,transparent_25%,rgba(68,68,68,.2)_25%,rgba(68,68,68,.2)_50%,transparent_50%,transparent_75%,rgba(68,68,68,.2)_75%)] bg-[length:4px_4px] opacity-30"></div>
      </div>

      {/* Main title */}
      <div className="relative">
        <h1 className="text-7xl md:text-8xl font-bold text-center mb-8 bg-clip-text text-transparent bg-gradient-to-r from-purple-400 via-pink-500 to-purple-400 animate-gradient">
          The official Nicz
        </h1>
      </div>

      {/* Sliding text banners */}
      <div className="relative">
        <div className="flex overflow-hidden space-x-4 group">
          <div className="flex space-x-4 animate-scroll group-hover:pause">
            {[...Array(2)].map((_, i) => (
              <div key={i} className="flex space-x-4 items-center whitespace-nowrap">
                {tools.map((tool) => {
                  const Icon = tool.icon;
                  return (
                    <div key={tool.name} className="flex items-center space-x-2 bg-white/5 backdrop-blur-sm px-4 py-2 rounded-full">
                      <Icon className="w-6 h-6 text-purple-400" />
                      <span className="text-white/80">{tool.name}</span>
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Tech grid with hover effects */}
      <div className="relative grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 px-4 max-w-7xl mx-auto">
        {tools.map((tool) => {
          const Icon = tool.icon;
          return (
            <div
              key={tool.name}
              className="group relative bg-white/5 backdrop-blur-sm rounded-xl p-4 hover:bg-white/10 transition-all duration-300 cursor-pointer overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-purple-500/10 to-pink-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              <Icon className="w-8 h-8 text-purple-400 group-hover:text-white transition-colors duration-300 relative z-10" />
              <p className="mt-2 text-sm text-white/70 group-hover:text-white transition-colors duration-300 relative z-10">{tool.name}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
}