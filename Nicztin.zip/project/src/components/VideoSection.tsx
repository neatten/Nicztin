import React from 'react';
import YouTube from 'react-youtube';

export default function VideoSection() {
  return (
    <section className="py-10 md:py-20 relative z-10">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-2xl md:text-3xl font-bold mb-4 md:mb-8 text-center text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-600">
          Featured Video
        </h2>
        <div className="aspect-video rounded-lg overflow-hidden shadow-2xl">
          <YouTube
            videoId="y0cwCfzup34"
            className="w-full"
            opts={{
              width: '100%',
              height: '100%',
              playerVars: {
                autoplay: 0,
              },
            }}
          />
        </div>
      </div>
    </section>
  );
}