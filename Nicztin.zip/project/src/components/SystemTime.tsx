import React, { useState, useEffect } from 'react';

export default function SystemTime() {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="bg-white/5 backdrop-blur-lg rounded-lg p-4 text-center">
      <h2 className="text-xl font-semibold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-600">
        System Time
      </h2>
      <p className="text-3xl font-bold mt-2 text-white">
        {time.toLocaleTimeString()}
      </p>
      <p className="text-sm text-gray-400">
        {time.toLocaleDateString()}
      </p>
    </div>
  );
}