import React from 'react';
import { Upload, Music } from 'lucide-react';

export default function MusicUpload() {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
  };

  return (
    <section className="py-20 relative z-10">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold mb-12 text-center text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-600">
          Upload Your Music
        </h2>
        
        <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-8 shadow-2xl border border-white/10">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="music" className="block text-lg font-medium text-gray-200 mb-2">
                Upload Music or Photo:
              </label>
              <div className="relative">
                <input
                  type="file"
                  id="music"
                  name="music"
                  accept="audio/*, image/*"
                  required
                  className="w-full px-4 py-3 rounded-xl bg-black/50 text-white border border-white/10 focus:border-purple-500 focus:ring-2 focus:ring-purple-500 transition-all duration-200
                    file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 
                    file:bg-purple-500 file:text-white
                    hover:file:bg-purple-600 file:transition-all file:duration-200"
                />
                <Upload className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
              </div>
            </div>

            <div>
              <label htmlFor="soundcloudLink" className="block text-lg font-medium text-gray-200 mb-2">
                SoundCloud Link:
              </label>
              <div className="relative">
                <input
                  type="url"
                  id="soundcloudLink"
                  name="soundcloudLink"
                  placeholder="Enter SoundCloud URL"
                  required
                  className="w-full px-4 py-3 rounded-xl bg-black/50 text-white border border-white/10 placeholder-gray-500
                    focus:border-purple-500 focus:ring-2 focus:ring-purple-500 transition-all duration-200"
                />
                <Music className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white py-3 px-6 rounded-xl
                text-lg font-medium hover:from-purple-600 hover:to-pink-600 transition-all duration-200
                shadow-[0_0_15px_rgba(168,85,247,0.5)] hover:shadow-[0_0_20px_rgba(168,85,247,0.6)]"
            >
              Upload
            </button>
          </form>
        </div>

        <div className="mt-12 text-center">
          <h3 className="text-2xl font-semibold mb-6 text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-600">
            Listen Music
          </h3>
          <div className="flex justify-center gap-4">
            <button
              onClick={() => window.location.href = '/uploads'}
              className="px-6 py-3 rounded-xl bg-white/5 backdrop-blur-lg border border-white/10 text-white
                hover:bg-white/10 transition-all duration-200 shadow-lg hover:shadow-xl
                hover:scale-105 hover:border-purple-500/50"
            >
              View Uploads
            </button>
            <button
              onClick={() => window.open('https://soundcloud.com/nicztin-enripue-864234512?ref=clipboard&p=a&c=1&si=71b85f9f10744d61a60d83b2a7fb9da9&utm_source=clipboard&utm_medium=text&utm_campaign=social_sharing', '_blank')}
              className="px-6 py-3 rounded-xl bg-white/5 backdrop-blur-lg border border-white/10 text-white
                hover:bg-white/10 transition-all duration-200 shadow-lg hover:shadow-xl
                hover:scale-105 hover:border-purple-500/50 group"
            >
              <span className="bg-gradient-to-r from-purple-400 to-pink-600 bg-clip-text text-transparent group-hover:text-white transition-colors duration-200">
                SoundCloud
              </span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}