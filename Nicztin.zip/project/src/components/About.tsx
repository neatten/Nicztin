import React from 'react';
import { Link } from 'lucide-react';

export default function About() {
  return (
    <section className="py-20 relative z-10">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold mb-8 text-center text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-600">
          About Nicztin
        </h2>
        
        <div className="prose prose-invert mx-auto space-y-6">
          <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-8 shadow-2xl border border-white/10">
            <p className="text-lg text-gray-300 leading-relaxed">
              Though I am not an IT expert or internet engineer, I've always carried a deep love for technology and music. 
              I'm the kind of person who speaks little, but listens and observes a lot — sometimes it takes me a whole year 
              to write one word, just to make sure it holds meaning.
            </p>
            
            <p className="text-lg text-gray-300 leading-relaxed mt-6">
              I'm currently an online entrepreneur — I sell watches, clothing, and perfumes. You can explore more of my work 
              and creative journey here: {' '}
              <a 
                href="https://lnk.bio/neatten" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-purple-400 hover:text-purple-300 transition-colors duration-300 inline-flex items-center gap-1"
              >
                lnk.bio/neatten <Link className="w-4 h-4" />
              </a>
            </p>

            <p className="text-lg text-gray-300 leading-relaxed mt-6">
              In my free time, I compose music — not as a career, but as a way to express feeling, memory, and depth in 
              everything I create. For me, music brings emotion; technology brings understanding. So I combined both into 
              a simple website: a space where art and code exist side by side.
            </p>

            <p className="text-lg text-gray-300 leading-relaxed mt-6">
              Even though my heart leans more toward music, I believe technology is a language of knowledge, and it's a 
              language we should all learn. That's why I've started creating platforms that are both artistic and 
              educational — not just to build, but to inspire. Not just to teach, but to connect.
            </p>

            <div className="mt-8 space-y-2 text-lg text-gray-300">
              <p>What I know, I'll share.</p>
              <p>What I see, I'll show.</p>
              <p>What I understand, I'll explain.</p>
              <p>Because I never guess — and I don't speak in maybes.</p>
            </div>

            <div className="mt-6">
              <h3 className="text-xl font-semibold mb-2 text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-600">
                This is what NE means:
              </h3>
              <p className="text-lg text-gray-300">
                Knowing with gratitude. Creating with purpose. Living with meaning.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}