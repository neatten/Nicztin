import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import TechStack from './components/TechStack';
import Footer from './components/Footer';
import StarBackground from './components/StarBackground';
import SystemTime from './components/SystemTime';
import VideoSection from './components/VideoSection';
import ScrollingLogos from './components/ScrollingLogos';
import MusicUpload from './components/MusicUpload';
import About from './components/About';

function App() {
  return (
    <div className="min-h-screen bg-black text-white relative">
      <StarBackground />
      <Navbar />
      <Hero />
      <ScrollingLogos />
      <main className="relative z-10">
        <section className="py-20">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl font-bold mb-8 text-center text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-600">
              Our Vision at Nicz
            </h2>
            <div className="prose prose-invert mx-auto">
              <p className="text-lg text-gray-300 text-center">
                We are a UK-based record label and music community specializing in electronic music. 
                Our mission is not to be the best but to create an open space for free musical expression. 
                Founded with purpose, not rigid structure, Nicz is about overcoming struggles and standing strong. 
                Here, we open our doors to provide free educational opportunities for anyone eager to learn and grow. We believe that sharing knowledge and the best of what we have is an invaluable investment in our community. Join us in building a vibrant, supportive community that thrives on growth, collaboration, and mutual inspiration.

Moreover, our platform seamlessly fuses cutting-edge technology with transformative music, celebrating the power of innovation and creative expression. We value those who dare to push boundaries and explore new horizons, merging art and tech to craft experiences that resonate and inspire. This unique blend of tech and music not only enriches our learning environment but also sparks groundbreaking ideas that elevate both disciplines.
              </p>
            </div>
          </div>
        </section>
        <MusicUpload />
        <About />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-20">
          <SystemTime />
        </div>
        <VideoSection />
        <TechStack />
      </main>
      <Footer />
    </div>
  );
}

export default App;